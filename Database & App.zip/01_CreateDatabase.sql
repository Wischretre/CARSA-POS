USE [master]
GO
/****** Object:  Database [sabares]    Script Date: 11/08/2026 01:33:06 PM ******/
CREATE DATABASE [sabares]
 CONTAINMENT = NONE
 ON  PRIMARY 
( NAME = N'sabares', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA\sabares.mdf' , SIZE = 8192KB , MAXSIZE = UNLIMITED, FILEGROWTH = 65536KB )
 LOG ON 
( NAME = N'sabares_log', FILENAME = N'C:\Program Files\Microsoft SQL Server\MSSQL17.SQLEXPRESS\MSSQL\DATA\sabares_log.ldf' , SIZE = 8192KB , MAXSIZE = 2048GB , FILEGROWTH = 65536KB )
 WITH CATALOG_COLLATION = DATABASE_DEFAULT, LEDGER = OFF
GO
ALTER DATABASE [sabares] SET COMPATIBILITY_LEVEL = 170
GO
IF (1 = FULLTEXTSERVICEPROPERTY('IsFullTextInstalled'))
begin
EXEC [sabares].[dbo].[sp_fulltext_database] @action = 'enable'
end
GO
ALTER DATABASE [sabares] SET ANSI_NULL_DEFAULT OFF 
GO
ALTER DATABASE [sabares] SET ANSI_NULLS OFF 
GO
ALTER DATABASE [sabares] SET ANSI_PADDING OFF 
GO
ALTER DATABASE [sabares] SET ANSI_WARNINGS OFF 
GO
ALTER DATABASE [sabares] SET ARITHABORT OFF 
GO
ALTER DATABASE [sabares] SET AUTO_CLOSE ON 
GO
ALTER DATABASE [sabares] SET AUTO_SHRINK OFF 
GO
ALTER DATABASE [sabares] SET AUTO_UPDATE_STATISTICS ON 
GO
ALTER DATABASE [sabares] SET CURSOR_CLOSE_ON_COMMIT OFF 
GO
ALTER DATABASE [sabares] SET CURSOR_DEFAULT  GLOBAL 
GO
ALTER DATABASE [sabares] SET CONCAT_NULL_YIELDS_NULL OFF 
GO
ALTER DATABASE [sabares] SET NUMERIC_ROUNDABORT OFF 
GO
ALTER DATABASE [sabares] SET QUOTED_IDENTIFIER OFF 
GO
ALTER DATABASE [sabares] SET RECURSIVE_TRIGGERS OFF 
GO
ALTER DATABASE [sabares] SET  ENABLE_BROKER 
GO
ALTER DATABASE [sabares] SET AUTO_UPDATE_STATISTICS_ASYNC OFF 
GO
ALTER DATABASE [sabares] SET DATE_CORRELATION_OPTIMIZATION OFF 
GO
ALTER DATABASE [sabares] SET TRUSTWORTHY OFF 
GO
ALTER DATABASE [sabares] SET ALLOW_SNAPSHOT_ISOLATION OFF 
GO
ALTER DATABASE [sabares] SET PARAMETERIZATION SIMPLE 
GO
ALTER DATABASE [sabares] SET READ_COMMITTED_SNAPSHOT OFF 
GO
ALTER DATABASE [sabares] SET HONOR_BROKER_PRIORITY OFF 
GO
ALTER DATABASE [sabares] SET RECOVERY SIMPLE 
GO
ALTER DATABASE [sabares] SET  MULTI_USER 
GO
ALTER DATABASE [sabares] SET PAGE_VERIFY CHECKSUM  
GO
ALTER DATABASE [sabares] SET DB_CHAINING OFF 
GO
ALTER DATABASE [sabares] SET FILESTREAM( NON_TRANSACTED_ACCESS = OFF ) 
GO
ALTER DATABASE [sabares] SET TARGET_RECOVERY_TIME = 60 SECONDS 
GO
ALTER DATABASE [sabares] SET DELAYED_DURABILITY = DISABLED 
GO
ALTER DATABASE [sabares] SET OPTIMIZED_LOCKING = OFF 
GO
ALTER DATABASE [sabares] SET ACCELERATED_DATABASE_RECOVERY = OFF  
GO
ALTER DATABASE [sabares] SET QUERY_STORE = ON
GO
ALTER DATABASE [sabares] SET QUERY_STORE (OPERATION_MODE = READ_WRITE, CLEANUP_POLICY = (STALE_QUERY_THRESHOLD_DAYS = 30), DATA_FLUSH_INTERVAL_SECONDS = 900, INTERVAL_LENGTH_MINUTES = 60, MAX_STORAGE_SIZE_MB = 1000, QUERY_CAPTURE_MODE = AUTO, SIZE_BASED_CLEANUP_MODE = AUTO, MAX_PLANS_PER_QUERY = 200, WAIT_STATS_CAPTURE_MODE = ON)
GO
USE [sabares]
GO
/****** Object:  Table [dbo].[AuditLog]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[AuditLog](
	[AuditId] [int] IDENTITY(1,1) NOT NULL,
	[OccurredAt] [datetime2](7) NOT NULL,
	[ActorUserId] [int] NULL,
	[Action] [nvarchar](50) NOT NULL,
	[TargetUserId] [int] NULL,
	[Details] [nvarchar](500) NULL,
PRIMARY KEY CLUSTERED 
(
	[AuditId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Categories]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Categories](
	[CategoryId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
	[Description] [nvarchar](200) NULL,
 CONSTRAINT [PK_Categories] PRIMARY KEY CLUSTERED 
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Categories_Name] UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Customers]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Customers](
	[CustomerId] [int] IDENTITY(1,1) NOT NULL,
	[FullName] [nvarchar](100) NOT NULL,
	[Phone] [nvarchar](30) NULL,
	[Email] [nvarchar](120) NULL,
	[Address] [nvarchar](250) NULL,
	[CreatedAt] [datetime] NOT NULL,
 CONSTRAINT [PK_Customers] PRIMARY KEY CLUSTERED 
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[InventoryLog]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[InventoryLog](
	[LogId] [int] IDENTITY(1,1) NOT NULL,
	[ProductId] [int] NOT NULL,
	[ChangeQty] [int] NOT NULL,
	[Reason] [nvarchar](200) NOT NULL,
	[UserId] [int] NOT NULL,
	[CreatedAt] [datetime] NOT NULL,
 CONSTRAINT [PK_InventoryLog] PRIMARY KEY CLUSTERED 
(
	[LogId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[OrderDetails]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[OrderDetails](
	[OrderDetailId] [int] IDENTITY(1,1) NOT NULL,
	[OrderId] [int] NOT NULL,
	[ProductId] [int] NOT NULL,
	[Quantity] [int] NOT NULL,
	[UnitPrice] [decimal](18, 2) NOT NULL,
	[LineTotal] [decimal](18, 2) NOT NULL,
 CONSTRAINT [PK_OrderDetails] PRIMARY KEY CLUSTERED 
(
	[OrderDetailId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Orders]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Orders](
	[OrderId] [int] IDENTITY(1,1) NOT NULL,
	[OrderNumber] [nvarchar](30) NOT NULL,
	[CustomerId] [int] NULL,
	[UserId] [int] NOT NULL,
	[OrderDate] [datetime] NOT NULL,
	[Subtotal] [decimal](18, 2) NOT NULL,
	[TaxAmount] [decimal](18, 2) NOT NULL,
	[DiscountAmount] [decimal](18, 2) NOT NULL,
	[Total] [decimal](18, 2) NOT NULL,
	[PaymentMethod] [nvarchar](20) NOT NULL,
	[AmountPaid] [decimal](18, 2) NOT NULL,
	[ChangeDue] [decimal](18, 2) NOT NULL,
	[Status] [nvarchar](20) NOT NULL,
 CONSTRAINT [PK_Orders] PRIMARY KEY CLUSTERED 
(
	[OrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Orders_Number] UNIQUE NONCLUSTERED 
(
	[OrderNumber] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Permissions]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Permissions](
	[PermissionId] [int] IDENTITY(1,1) NOT NULL,
	[Name] [nvarchar](100) NOT NULL,
PRIMARY KEY CLUSTERED 
(
	[PermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
UNIQUE NONCLUSTERED 
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Products]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Products](
	[ProductId] [int] IDENTITY(1,1) NOT NULL,
	[Sku] [nvarchar](30) NOT NULL,
	[Barcode] [nvarchar](50) NULL,
	[Name] [nvarchar](150) NOT NULL,
	[CategoryId] [int] NOT NULL,
	[Price] [decimal](18, 2) NOT NULL,
	[Cost] [decimal](18, 2) NOT NULL,
	[StockQty] [int] NOT NULL,
	[ReorderLevel] [int] NOT NULL,
	[Image] [varbinary](max) NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime] NOT NULL,
	[UpdatedAt] [datetime] NOT NULL,
	[ImagePath] [nvarchar](260) NULL,
 CONSTRAINT [PK_Products] PRIMARY KEY CLUSTERED 
(
	[ProductId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Products_Sku] UNIQUE NONCLUSTERED 
(
	[Sku] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY] TEXTIMAGE_ON [PRIMARY]
GO
/****** Object:  Table [dbo].[RolePermissions]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[RolePermissions](
	[RoleId] [int] NOT NULL,
	[PermissionId] [int] NOT NULL,
 CONSTRAINT [PK_RolePermissions] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC,
	[PermissionId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Roles]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Roles](
	[RoleId] [int] IDENTITY(1,1) NOT NULL,
	[RoleName] [nvarchar](50) NOT NULL,
	[Description] [nvarchar](200) NULL,
 CONSTRAINT [PK_Roles] PRIMARY KEY CLUSTERED 
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Roles_RoleName] UNIQUE NONCLUSTERED 
(
	[RoleName] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Table [dbo].[Users]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[Users](
	[UserId] [int] IDENTITY(1,1) NOT NULL,
	[Username] [nvarchar](50) NOT NULL,
	[PasswordHash] [varchar](64) NOT NULL,
	[Salt] [varchar](32) NOT NULL,
	[FullName] [nvarchar](100) NOT NULL,
	[RoleId] [int] NOT NULL,
	[IsActive] [bit] NOT NULL,
	[CreatedAt] [datetime] NOT NULL,
	[LastLoginAt] [datetime] NULL,
 CONSTRAINT [PK_Users] PRIMARY KEY CLUSTERED 
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY],
 CONSTRAINT [UQ_Users_Username] UNIQUE NONCLUSTERED 
(
	[Username] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO
/****** Object:  Index [IX_InventoryLog_Product]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_InventoryLog_Product] ON [dbo].[InventoryLog]
(
	[ProductId] ASC,
	[CreatedAt] DESC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_OrderDetails_OrderId]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_OrderDetails_OrderId] ON [dbo].[OrderDetails]
(
	[OrderId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_OrderDetails_ProductId]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_OrderDetails_ProductId] ON [dbo].[OrderDetails]
(
	[ProductId] ASC
)
INCLUDE([Quantity],[LineTotal]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Orders_CustomerId]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_Orders_CustomerId] ON [dbo].[Orders]
(
	[CustomerId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Orders_OrderDate]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_Orders_OrderDate] ON [dbo].[Orders]
(
	[OrderDate] ASC
)
INCLUDE([Total],[Status]) WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Orders_UserId]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_Orders_UserId] ON [dbo].[Orders]
(
	[UserId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Products_CategoryId]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_Products_CategoryId] ON [dbo].[Products]
(
	[CategoryId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [IX_Products_Name]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_Products_Name] ON [dbo].[Products]
(
	[Name] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
SET ANSI_PADDING ON
GO
/****** Object:  Index [UX_Products_Barcode]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE UNIQUE NONCLUSTERED INDEX [UX_Products_Barcode] ON [dbo].[Products]
(
	[Barcode] ASC
)
WHERE ([Barcode] IS NOT NULL)
WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, IGNORE_DUP_KEY = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
/****** Object:  Index [IX_Users_RoleId]    Script Date: 11/08/2026 01:33:07 PM ******/
CREATE NONCLUSTERED INDEX [IX_Users_RoleId] ON [dbo].[Users]
(
	[RoleId] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, SORT_IN_TEMPDB = OFF, DROP_EXISTING = OFF, ONLINE = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
GO
ALTER TABLE [dbo].[AuditLog] ADD  CONSTRAINT [DF_AuditLog_OccurredAt]  DEFAULT (sysdatetime()) FOR [OccurredAt]
GO
ALTER TABLE [dbo].[Customers] ADD  CONSTRAINT [DF_Customers_CreatedAt]  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[InventoryLog] ADD  CONSTRAINT [DF_InventoryLog_Created]  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Orders] ADD  CONSTRAINT [DF_Orders_Date]  DEFAULT (getdate()) FOR [OrderDate]
GO
ALTER TABLE [dbo].[Orders] ADD  CONSTRAINT [DF_Orders_Discount]  DEFAULT ((0)) FOR [DiscountAmount]
GO
ALTER TABLE [dbo].[Orders] ADD  CONSTRAINT [DF_Orders_Status]  DEFAULT (N'Completed') FOR [Status]
GO
ALTER TABLE [dbo].[Products] ADD  CONSTRAINT [DF_Products_Stock]  DEFAULT ((0)) FOR [StockQty]
GO
ALTER TABLE [dbo].[Products] ADD  CONSTRAINT [DF_Products_Reorder]  DEFAULT ((5)) FOR [ReorderLevel]
GO
ALTER TABLE [dbo].[Products] ADD  CONSTRAINT [DF_Products_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Products] ADD  CONSTRAINT [DF_Products_CreatedAt]  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[Products] ADD  CONSTRAINT [DF_Products_UpdatedAt]  DEFAULT (getdate()) FOR [UpdatedAt]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_IsActive]  DEFAULT ((1)) FOR [IsActive]
GO
ALTER TABLE [dbo].[Users] ADD  CONSTRAINT [DF_Users_CreatedAt]  DEFAULT (getdate()) FOR [CreatedAt]
GO
ALTER TABLE [dbo].[AuditLog]  WITH CHECK ADD  CONSTRAINT [FK_AuditLog_Actor] FOREIGN KEY([ActorUserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[AuditLog] CHECK CONSTRAINT [FK_AuditLog_Actor]
GO
ALTER TABLE [dbo].[AuditLog]  WITH CHECK ADD  CONSTRAINT [FK_AuditLog_Target] FOREIGN KEY([TargetUserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[AuditLog] CHECK CONSTRAINT [FK_AuditLog_Target]
GO
ALTER TABLE [dbo].[InventoryLog]  WITH CHECK ADD  CONSTRAINT [FK_InventoryLog_Products] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[InventoryLog] CHECK CONSTRAINT [FK_InventoryLog_Products]
GO
ALTER TABLE [dbo].[InventoryLog]  WITH CHECK ADD  CONSTRAINT [FK_InventoryLog_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[InventoryLog] CHECK CONSTRAINT [FK_InventoryLog_Users]
GO
ALTER TABLE [dbo].[OrderDetails]  WITH CHECK ADD  CONSTRAINT [FK_OrderDetails_Orders] FOREIGN KEY([OrderId])
REFERENCES [dbo].[Orders] ([OrderId])
ON DELETE CASCADE
GO
ALTER TABLE [dbo].[OrderDetails] CHECK CONSTRAINT [FK_OrderDetails_Orders]
GO
ALTER TABLE [dbo].[OrderDetails]  WITH CHECK ADD  CONSTRAINT [FK_OrderDetails_Products] FOREIGN KEY([ProductId])
REFERENCES [dbo].[Products] ([ProductId])
GO
ALTER TABLE [dbo].[OrderDetails] CHECK CONSTRAINT [FK_OrderDetails_Products]
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Customers] FOREIGN KEY([CustomerId])
REFERENCES [dbo].[Customers] ([CustomerId])
GO
ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Customers]
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [FK_Orders_Users] FOREIGN KEY([UserId])
REFERENCES [dbo].[Users] ([UserId])
GO
ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [FK_Orders_Users]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [FK_Products_Categories] FOREIGN KEY([CategoryId])
REFERENCES [dbo].[Categories] ([CategoryId])
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [FK_Products_Categories]
GO
ALTER TABLE [dbo].[RolePermissions]  WITH CHECK ADD  CONSTRAINT [FK_RolePermissions_Permissions] FOREIGN KEY([PermissionId])
REFERENCES [dbo].[Permissions] ([PermissionId])
GO
ALTER TABLE [dbo].[RolePermissions] CHECK CONSTRAINT [FK_RolePermissions_Permissions]
GO
ALTER TABLE [dbo].[RolePermissions]  WITH CHECK ADD  CONSTRAINT [FK_RolePermissions_Roles] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Roles] ([RoleId])
GO
ALTER TABLE [dbo].[RolePermissions] CHECK CONSTRAINT [FK_RolePermissions_Roles]
GO
ALTER TABLE [dbo].[Users]  WITH CHECK ADD  CONSTRAINT [FK_Users_Roles] FOREIGN KEY([RoleId])
REFERENCES [dbo].[Roles] ([RoleId])
GO
ALTER TABLE [dbo].[Users] CHECK CONSTRAINT [FK_Users_Roles]
GO
ALTER TABLE [dbo].[OrderDetails]  WITH CHECK ADD  CONSTRAINT [CK_OrderDetails_Qty] CHECK  (([Quantity]>(0)))
GO
ALTER TABLE [dbo].[OrderDetails] CHECK CONSTRAINT [CK_OrderDetails_Qty]
GO
ALTER TABLE [dbo].[OrderDetails]  WITH CHECK ADD  CONSTRAINT [CK_OrderDetails_Quantity] CHECK  (([Quantity]>=(1)))
GO
ALTER TABLE [dbo].[OrderDetails] CHECK CONSTRAINT [CK_OrderDetails_Quantity]
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [CK_Orders_Payment] CHECK  (([PaymentMethod]=N'Mobile' OR [PaymentMethod]=N'Card' OR [PaymentMethod]=N'Cash'))
GO
ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [CK_Orders_Payment]
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [CK_Orders_PaymentMethod] CHECK  (([PaymentMethod]='Mobile' OR [PaymentMethod]='Card' OR [PaymentMethod]='Cash'))
GO
ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [CK_Orders_PaymentMethod]
GO
ALTER TABLE [dbo].[Orders]  WITH CHECK ADD  CONSTRAINT [CK_Orders_Status] CHECK  (([Status]=N'Voided' OR [Status]=N'Completed'))
GO
ALTER TABLE [dbo].[Orders] CHECK CONSTRAINT [CK_Orders_Status]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [CK_Products_Cost] CHECK  (([Cost]>=(0)))
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [CK_Products_Cost]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [CK_Products_NonNegative] CHECK  (([Price]>=(0) AND [Cost]>=(0) AND [StockQty]>=(0) AND [ReorderLevel]>=(0)))
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [CK_Products_NonNegative]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [CK_Products_Price] CHECK  (([Price]>=(0)))
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [CK_Products_Price]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [CK_Products_Reorder] CHECK  (([ReorderLevel]>=(0)))
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [CK_Products_Reorder]
GO
ALTER TABLE [dbo].[Products]  WITH CHECK ADD  CONSTRAINT [CK_Products_Stock] CHECK  (([StockQty]>=(0)))
GO
ALTER TABLE [dbo].[Products] CHECK CONSTRAINT [CK_Products_Stock]
GO
/****** Object:  StoredProcedure [dbo].[usp_Audit_Insert]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Writes one audit entry.
CREATE   PROCEDURE [dbo].[usp_Audit_Insert]
    @ActorUserId INT,
    @Action NVARCHAR(50),
    @TargetUserId INT = NULL,
    @Details NVARCHAR(500) = NULL
AS
BEGIN
    SET NOCOUNT ON;

    INSERT INTO dbo.AuditLog (ActorUserId, Action, TargetUserId, Details)
    VALUES (@ActorUserId, @Action, @TargetUserId, @Details);
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Audit_List]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Reads audit entries in a date range, newest first. Pass a TargetUserId to filter to one user.
CREATE   PROCEDURE [dbo].[usp_Audit_List]
    @From DATETIME2,
    @To DATETIME2,
    @TargetUserId INT = NULL
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (500)
        a.AuditId,
        a.OccurredAt,
        actor.Username AS ActorUsername,
        a.Action,
        target.Username AS TargetUsername,
        a.Details
    FROM dbo.AuditLog a
    LEFT JOIN dbo.Users actor ON actor.UserId = a.ActorUserId
    LEFT JOIN dbo.Users target ON target.UserId = a.TargetUserId
    WHERE a.OccurredAt >= @From
      AND a.OccurredAt < @To
      AND (@TargetUserId IS NULL OR a.TargetUserId = @TargetUserId)
    ORDER BY a.OccurredAt DESC, a.AuditId DESC;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Category_List]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_Category_List]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CategoryId, Name, Description FROM dbo.Categories ORDER BY Name;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Customer_List]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_Customer_List]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CustomerId, FullName, Phone, Email, Address, CreatedAt FROM dbo.Customers ORDER BY FullName;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Inventory_Adjust]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ===================== INVENTORY ===================== */
CREATE   PROCEDURE [dbo].[usp_Inventory_Adjust]
    @ProductId INT, @ChangeQty INT, @Reason NVARCHAR(200), @UserId INT
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRAN;
        DECLARE @Cur INT;
        SELECT @Cur = StockQty FROM dbo.Products WITH (UPDLOCK, ROWLOCK) WHERE ProductId = @ProductId;
        IF @Cur IS NULL THROW 50010, N'Product not found.', 1;
        IF @Cur + @ChangeQty < 0 THROW 50011, N'Adjustment would make stock negative.', 1;
        UPDATE dbo.Products SET StockQty = @Cur + @ChangeQty, UpdatedAt = GETDATE() WHERE ProductId = @ProductId;
        INSERT dbo.InventoryLog (ProductId, ChangeQty, Reason, UserId) VALUES (@ProductId, @ChangeQty, @Reason, @UserId);
        COMMIT;
        SELECT @Cur + @ChangeQty AS NewStock;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Login]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ===================== AUTH ===================== */
CREATE   PROCEDURE [dbo].[usp_Login] @Username NVARCHAR(50)
AS
BEGIN
    SET NOCOUNT ON;
    SELECT u.UserId, u.Username, u.PasswordHash, u.Salt, u.FullName, u.RoleId, r.RoleName, u.IsActive
    FROM dbo.Users u JOIN dbo.Roles r ON r.RoleId = u.RoleId
    WHERE u.Username = @Username;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Order_Create]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ===================== ORDERS (transactional) ===================== */
CREATE   PROCEDURE [dbo].[usp_Order_Create]
    @UserId INT, @CustomerId INT = NULL, @PaymentMethod NVARCHAR(20),
    @DiscountAmount DECIMAL(18,2) = 0, @TaxRate DECIMAL(5,2) = 0, @AmountPaid DECIMAL(18,2),
    @ItemsXml XML      -- <Items><Item ProductId="1" Quantity="2"/></Items>
AS
BEGIN
    SET NOCOUNT ON; SET XACT_ABORT ON;
    BEGIN TRY
        BEGIN TRAN;
        DECLARE @Items TABLE (ProductId INT NOT NULL PRIMARY KEY, Quantity INT NOT NULL);
        INSERT @Items (ProductId, Quantity)
        SELECT ProductId, SUM(Quantity)
        FROM (SELECT x.value('@ProductId', 'INT') AS ProductId, x.value('@Quantity', 'INT') AS Quantity
              FROM @ItemsXml.nodes('/Items/Item') AS t(x)) s
        GROUP BY ProductId;
        IF NOT EXISTS (SELECT 1 FROM @Items) THROW 50020, N'The order has no items.', 1;
        IF EXISTS (SELECT 1 FROM @Items WHERE Quantity <= 0) THROW 50021, N'Invalid item quantity.', 1;
        -- lock rows & validate availability (prices are always taken from the database)
        IF EXISTS (SELECT 1 FROM @Items i
                   LEFT JOIN dbo.Products p WITH (UPDLOCK, ROWLOCK) ON p.ProductId = i.ProductId
                   WHERE p.ProductId IS NULL OR p.IsActive = 0)
            THROW 50022, N'One or more products are unavailable.', 1;
        DECLARE @Msg NVARCHAR(200) =
            (SELECT TOP 1 N'Insufficient stock for ' + p.Name + N' (available: ' + CAST(p.StockQty AS NVARCHAR(10)) + N').'
             FROM @Items i JOIN dbo.Products p ON p.ProductId = i.ProductId WHERE p.StockQty < i.Quantity);
        IF @Msg IS NOT NULL THROW 50023, @Msg, 1;
        DECLARE @Subtotal DECIMAL(18,2) =
            (SELECT SUM(p.Price * i.Quantity) FROM @Items i JOIN dbo.Products p ON p.ProductId = i.ProductId);
        IF @DiscountAmount < 0 OR @DiscountAmount > @Subtotal THROW 50024, N'Invalid discount amount.', 1;
        DECLARE @Tax DECIMAL(18,2)   = ROUND((@Subtotal - @DiscountAmount) * @TaxRate / 100.0, 2);
        DECLARE @Total DECIMAL(18,2) = @Subtotal - @DiscountAmount + @Tax;
        IF @AmountPaid < @Total THROW 50025, N'Amount paid is less than the total.', 1;
        INSERT dbo.Orders (OrderNumber, CustomerId, UserId, OrderDate, Subtotal, TaxAmount, DiscountAmount, Total,
                           PaymentMethod, AmountPaid, ChangeDue, Status)
        VALUES (LEFT(CONVERT(NVARCHAR(36), NEWID()), 30), @CustomerId, @UserId, GETDATE(), @Subtotal, @Tax, @DiscountAmount, @Total,
                @PaymentMethod, @AmountPaid, @AmountPaid - @Total, N'Completed');
        DECLARE @OrderId INT = SCOPE_IDENTITY();
        DECLARE @OrderNumber NVARCHAR(30) = N'ORD-' + CONVERT(NVARCHAR(8), GETDATE(), 112) + N'-' + RIGHT(N'000000' + CAST(@OrderId AS NVARCHAR(10)), 6);
        UPDATE dbo.Orders SET OrderNumber = @OrderNumber WHERE OrderId = @OrderId;
        INSERT dbo.OrderDetails (OrderId, ProductId, Quantity, UnitPrice, LineTotal)
        SELECT @OrderId, i.ProductId, i.Quantity, p.Price, p.Price * i.Quantity
        FROM @Items i JOIN dbo.Products p ON p.ProductId = i.ProductId;
        UPDATE p SET StockQty = p.StockQty - i.Quantity, UpdatedAt = GETDATE()
        FROM dbo.Products p JOIN @Items i ON i.ProductId = p.ProductId;
        INSERT dbo.InventoryLog (ProductId, ChangeQty, Reason, UserId)
        SELECT i.ProductId, -i.Quantity, N'Sale ' + @OrderNumber, @UserId FROM @Items i;
        COMMIT;
        SELECT @OrderId AS Id;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK;
        THROW;
    END CATCH
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Order_Get]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_Order_Get] @OrderId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT OrderId, OrderNumber, CustomerId, UserId, OrderDate, Subtotal, TaxAmount,
           DiscountAmount, Total, PaymentMethod, AmountPaid, ChangeDue, Status
    FROM dbo.Orders WHERE OrderId = @OrderId;

    SELECT d.OrderDetailId, d.OrderId, d.ProductId, p.Name AS ProductName,
           d.Quantity, d.UnitPrice, d.LineTotal
    FROM dbo.OrderDetails d
    JOIN dbo.Products p ON p.ProductId = d.ProductId
    WHERE d.OrderId = @OrderId
    ORDER BY d.OrderDetailId;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Order_Recent]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

CREATE   PROCEDURE [dbo].[usp_Order_Recent]
    @Top INT = 10
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (@Top)
        o.OrderId,
        o.OrderNumber,
        o.OrderDate,
        o.Total,
        o.PaymentMethod,
        o.Status,
        u.FullName AS CashierName
    FROM dbo.Orders o
    INNER JOIN dbo.Users u ON u.UserId = o.UserId
    ORDER BY o.OrderDate DESC, o.OrderId DESC;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Permission_ListForUser]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Permissions for one user, found through the user's role.
CREATE   PROCEDURE [dbo].[usp_Permission_ListForUser]
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT p.Name AS PermissionName
    FROM dbo.Users u
    INNER JOIN dbo.RolePermissions rp ON rp.RoleId = u.RoleId
    INNER JOIN dbo.Permissions p ON p.PermissionId = rp.PermissionId
    WHERE u.UserId = @UserId
      AND u.IsActive = 1
    ORDER BY p.Name;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Delete]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_Product_Delete] @ProductId INT   -- soft delete keeps sales history intact
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.Products SET IsActive = 0, UpdatedAt = GETDATE() WHERE ProductId = @ProductId;
    IF @@ROWCOUNT = 0 THROW 50001, N'Product not found.', 1;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_GetById]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- 4. Get by ID: returns ImagePath.
CREATE   PROCEDURE [dbo].[usp_Product_GetById]
    @ProductId INT
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ProductId, Sku, Barcode, Name, CategoryId, Price, Cost,
           StockQty, ReorderLevel, ImagePath, IsActive, CreatedAt, UpdatedAt
    FROM dbo.Products
    WHERE ProductId = @ProductId;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Insert]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- 2. Insert: takes ImagePath instead of image bytes. Logs opening stock.
CREATE   PROCEDURE [dbo].[usp_Product_Insert]
    @Sku NVARCHAR(30),
    @Barcode NVARCHAR(50) = NULL,
    @Name NVARCHAR(150),
    @CategoryId INT,
    @Price DECIMAL(18,2),
    @Cost DECIMAL(18,2),
    @StockQty INT,
    @ReorderLevel INT,
    @ImagePath NVARCHAR(260) = NULL,
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    BEGIN TRY
        BEGIN TRANSACTION;

        INSERT INTO dbo.Products
            (Sku, Barcode, Name, CategoryId, Price, Cost, StockQty, ReorderLevel, ImagePath, IsActive, CreatedAt, UpdatedAt)
        VALUES
            (@Sku, @Barcode, @Name, @CategoryId, @Price, @Cost, @StockQty, @ReorderLevel, @ImagePath, 1, SYSDATETIME(), SYSDATETIME());

        DECLARE @NewId INT = SCOPE_IDENTITY();

        IF @StockQty > 0
            INSERT INTO dbo.InventoryLog (ProductId, ChangeQty, Reason, UserId, CreatedAt)
            VALUES (@NewId, @StockQty, N'Opening stock', @UserId, SYSDATETIME());

        COMMIT TRANSACTION;
        SELECT @NewId AS ProductId;
    END TRY
    BEGIN CATCH
        IF @@TRANCOUNT > 0 ROLLBACK TRANSACTION;
        THROW;
    END CATCH
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Search]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- 5. Search: returns ImagePath for the grid thumbnails.
CREATE   PROCEDURE [dbo].[usp_Product_Search]
    @Search NVARCHAR(150) = NULL,
    @LowStockOnly BIT = 0,
    @IncludeInactive BIT = 0
AS
BEGIN
    SET NOCOUNT ON;
    SELECT p.ProductId, p.Sku, p.Barcode, p.Name, p.CategoryId,
           c.Name AS CategoryName, p.Price, p.Cost, p.StockQty,
           p.ReorderLevel, p.ImagePath, p.IsActive,
           CASE WHEN p.StockQty <= p.ReorderLevel THEN 1 ELSE 0 END AS IsLowStock
    FROM dbo.Products p
    INNER JOIN dbo.Categories c ON c.CategoryId = p.CategoryId
    WHERE (@IncludeInactive = 1 OR p.IsActive = 1)
      AND (@LowStockOnly = 0 OR p.StockQty <= p.ReorderLevel)
      AND (@Search IS NULL
           OR p.Sku LIKE '%' + @Search + '%'
           OR p.Barcode LIKE '%' + @Search + '%'
           OR p.Name LIKE '%' + @Search + '%')
    ORDER BY p.Name;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Product_Update]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- 3. Update: sets ImagePath. The form passes the existing path when the image is unchanged.
CREATE   PROCEDURE [dbo].[usp_Product_Update]
    @ProductId INT,
    @Sku NVARCHAR(30),
    @Barcode NVARCHAR(50) = NULL,
    @Name NVARCHAR(150),
    @CategoryId INT,
    @Price DECIMAL(18,2),
    @Cost DECIMAL(18,2),
    @ReorderLevel INT,
    @IsActive BIT,
    @ImagePath NVARCHAR(260) = NULL
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.Products
    SET Sku = @Sku,
        Barcode = @Barcode,
        Name = @Name,
        CategoryId = @CategoryId,
        Price = @Price,
        Cost = @Cost,
        ReorderLevel = @ReorderLevel,
        IsActive = @IsActive,
        ImagePath = @ImagePath,
        UpdatedAt = SYSDATETIME()
    WHERE ProductId = @ProductId;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_DailySales]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
/* ===================== REPORTS ===================== */
CREATE   PROCEDURE [dbo].[usp_Report_DailySales] @From DATETIME, @To DATETIME
AS
BEGIN
    SET NOCOUNT ON;
    SELECT CAST(OrderDate AS DATE) AS SaleDate, COUNT(*) AS OrderCount, SUM(Total) AS Revenue
    FROM dbo.Orders
    WHERE Status = N'Completed' AND OrderDate >= @From AND OrderDate < DATEADD(DAY, 1, @To)
    GROUP BY CAST(OrderDate AS DATE)
    ORDER BY SaleDate;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_Dashboard]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_Report_Dashboard]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT
      (SELECT ISNULL(SUM(Total), 0) FROM dbo.Orders WHERE Status = N'Completed' AND OrderDate >= CAST(GETDATE() AS DATE)) AS TodaySales,
      (SELECT COUNT(*)              FROM dbo.Orders WHERE Status = N'Completed' AND OrderDate >= CAST(GETDATE() AS DATE)) AS TodayOrders,
      (SELECT COUNT(*) FROM dbo.Products WHERE IsActive = 1 AND StockQty <= ReorderLevel) AS LowStockCount,
      (SELECT COUNT(*) FROM dbo.Products WHERE IsActive = 1) AS ActiveProducts;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_InventoryValuation]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Inventory valuation for active products. No date range, because it reflects current stock.
CREATE   PROCEDURE [dbo].[usp_Report_InventoryValuation]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        p.Sku,
        p.Name,
        p.StockQty,
        p.Cost,
        p.Price,
        CAST(p.StockQty * p.Cost AS DECIMAL(18,2)) AS CostValue,
        CAST(p.StockQty * p.Price AS DECIMAL(18,2)) AS RetailValue
    FROM dbo.Products p
    WHERE p.IsActive = 1
    ORDER BY p.Name;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_LowStock]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_Report_LowStock]
AS
BEGIN
    SET NOCOUNT ON;
    SELECT ProductId, Sku, Name, StockQty, ReorderLevel
    FROM dbo.Products WHERE IsActive = 1 AND StockQty <= ReorderLevel
    ORDER BY StockQty, Name;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_Sales]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Daily sales for a date range. @To is exclusive, so the UI passes the day after the last day.
CREATE   PROCEDURE [dbo].[usp_Report_Sales]
    @From DATETIME2,
    @To DATETIME2
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        CAST(o.OrderDate AS DATE) AS SaleDay,
        COUNT(*) AS OrderCount,
        SUM(o.Subtotal) AS GrossSales,
        SUM(o.DiscountAmount) AS Discounts,
        SUM(o.TaxAmount) AS TaxTotal,
        SUM(o.Total) AS NetSales
    FROM dbo.Orders o
    WHERE o.Status = 'Completed'
      AND o.OrderDate >= @From
      AND o.OrderDate < @To
    GROUP BY CAST(o.OrderDate AS DATE)
    ORDER BY SaleDay;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_SalesByCashier]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Sales by cashier.
CREATE   PROCEDURE [dbo].[usp_Report_SalesByCashier]
    @From DATETIME2,
    @To DATETIME2
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.FullName AS CashierName,
        COUNT(*) AS OrderCount,
        SUM(o.Total) AS NetSales
    FROM dbo.Orders o
    INNER JOIN dbo.Users u ON u.UserId = o.UserId
    WHERE o.Status = 'Completed'
      AND o.OrderDate >= @From
      AND o.OrderDate < @To
    GROUP BY u.FullName
    ORDER BY NetSales DESC;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_SalesByCategory]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Sales by category.
CREATE   PROCEDURE [dbo].[usp_Report_SalesByCategory]
    @From DATETIME2,
    @To DATETIME2
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        c.Name AS CategoryName,
        SUM(d.LineTotal) AS Revenue
    FROM dbo.OrderDetails d
    INNER JOIN dbo.Orders o ON o.OrderId = d.OrderId
    INNER JOIN dbo.Products p ON p.ProductId = d.ProductId
    INNER JOIN dbo.Categories c ON c.CategoryId = p.CategoryId
    WHERE o.Status = 'Completed'
      AND o.OrderDate >= @From
      AND o.OrderDate < @To
    GROUP BY c.Name
    ORDER BY Revenue DESC;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Report_TopProducts]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Top-selling products. The name now comes from dbo.Products, because dbo.OrderDetails has no ProductName column.
CREATE   PROCEDURE [dbo].[usp_Report_TopProducts]
    @From DATETIME2,
    @To DATETIME2,
    @Top INT = 10
AS
BEGIN
    SET NOCOUNT ON;

    SELECT TOP (@Top)
        p.Name AS ProductName,
        SUM(d.Quantity) AS QtySold,
        SUM(d.LineTotal) AS Revenue
    FROM dbo.OrderDetails d
    INNER JOIN dbo.Orders o ON o.OrderId = d.OrderId
    INNER JOIN dbo.Products p ON p.ProductId = d.ProductId
    WHERE o.Status = 'Completed'
      AND o.OrderDate >= @From
      AND o.OrderDate < @To
    GROUP BY p.ProductId, p.Name
    ORDER BY QtySold DESC, Revenue DESC;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_Role_List]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Roles list, for the role dropdown on the user screen.
CREATE   PROCEDURE [dbo].[usp_Role_List]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT RoleId, RoleName, Description
    FROM dbo.Roles
    ORDER BY RoleId;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_User_GetById]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- One user, for the edit screen.
CREATE   PROCEDURE [dbo].[usp_User_GetById]
    @UserId INT
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.RoleId,
        u.IsActive,
        u.LastLoginAt,
        u.CreatedAt
    FROM dbo.Users u
    WHERE u.UserId = @UserId;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_User_Insert]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Creates a user. The password hash and salt are created in C#, using the same method as login.
CREATE   PROCEDURE [dbo].[usp_User_Insert]
    @ActorUserId INT,
    @Username NVARCHAR(50),
    @PasswordHash NVARCHAR(200),
    @Salt NVARCHAR(200),
    @FullName NVARCHAR(100),
    @RoleId INT,
    @IsActive BIT,
    @NewUserId INT OUTPUT
AS
BEGIN
    SET NOCOUNT ON;

    IF EXISTS (SELECT 1 FROM dbo.Users WHERE Username = @Username)
    BEGIN
        RAISERROR(N'Username already exists.', 16, 1);
        RETURN;
    END

    INSERT INTO dbo.Users (Username, PasswordHash, Salt, FullName, RoleId, IsActive, CreatedAt)
    VALUES (@Username, @PasswordHash, @Salt, @FullName, @RoleId, @IsActive, SYSDATETIME());

    SET @NewUserId = SCOPE_IDENTITY();

    INSERT INTO dbo.AuditLog (ActorUserId, Action, TargetUserId, Details)
    VALUES (@ActorUserId, N'UserCreated', @NewUserId, CONCAT(N'Created ', @Username, N' with role ', @RoleId));
END
GO
/****** Object:  StoredProcedure [dbo].[usp_User_List]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- User list for the grid. Includes role name and last login.
CREATE   PROCEDURE [dbo].[usp_User_List]
AS
BEGIN
    SET NOCOUNT ON;

    SELECT
        u.UserId,
        u.Username,
        u.FullName,
        u.RoleId,
        r.RoleName,
        u.IsActive,
        u.LastLoginAt,
        u.CreatedAt
    FROM dbo.Users u
    INNER JOIN dbo.Roles r ON r.RoleId = u.RoleId
    ORDER BY u.FullName;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_User_SetPassword]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Resets a password. Only the hash and salt are stored, never the plain password.
CREATE   PROCEDURE [dbo].[usp_User_SetPassword]
    @ActorUserId INT,
    @UserId INT,
    @PasswordHash NVARCHAR(200),
    @Salt NVARCHAR(200)
AS
BEGIN
    SET NOCOUNT ON;

    UPDATE dbo.Users
    SET PasswordHash = @PasswordHash,
        Salt = @Salt
    WHERE UserId = @UserId;

    INSERT INTO dbo.AuditLog (ActorUserId, Action, TargetUserId, Details)
    VALUES (@ActorUserId, N'PasswordReset', @UserId, N'Password reset by administrator');
END
GO
/****** Object:  StoredProcedure [dbo].[usp_User_TouchLogin]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO
CREATE   PROCEDURE [dbo].[usp_User_TouchLogin] @UserId INT
AS
BEGIN
    SET NOCOUNT ON;
    UPDATE dbo.Users SET LastLoginAt = GETDATE() WHERE UserId = @UserId;
END
GO
/****** Object:  StoredProcedure [dbo].[usp_User_Update]    Script Date: 11/08/2026 01:33:07 PM ******/
SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO

-- Updates name, role, and active flag. Protects against locking yourself out.
CREATE   PROCEDURE [dbo].[usp_User_Update]
    @ActorUserId INT,
    @UserId INT,
    @FullName NVARCHAR(100),
    @RoleId INT,
    @IsActive BIT
AS
BEGIN
    SET NOCOUNT ON;

    IF @ActorUserId = @UserId AND (@IsActive = 0 OR @RoleId <> 1)
    BEGIN
        RAISERROR(N'You cannot deactivate or demote your own account.', 16, 1);
        RETURN;
    END

    -- Admin is RoleId 1. Block changes that would leave no active Admin.
    IF EXISTS (SELECT 1 FROM dbo.Users WHERE UserId = @UserId AND RoleId = 1 AND IsActive = 1)
       AND (@RoleId <> 1 OR @IsActive = 0)
       AND NOT EXISTS (SELECT 1 FROM dbo.Users WHERE RoleId = 1 AND IsActive = 1 AND UserId <> @UserId)
    BEGIN
        RAISERROR(N'At least one active Admin must remain.', 16, 1);
        RETURN;
    END

    UPDATE dbo.Users
    SET FullName = @FullName,
        RoleId = @RoleId,
        IsActive = @IsActive
    WHERE UserId = @UserId;

    INSERT INTO dbo.AuditLog (ActorUserId, Action, TargetUserId, Details)
    VALUES (@ActorUserId, N'UserUpdated', @UserId,
            CONCAT(N'Role ', @RoleId, N', active ', @IsActive));
END
GO
USE [master]
GO
ALTER DATABASE [sabares] SET  READ_WRITE 
GO
